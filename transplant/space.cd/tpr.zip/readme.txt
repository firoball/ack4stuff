edit client or server bat and replace "spielername" with your nickname.

arrows - control ship
ins/0 - strafe
f10/esc - quit